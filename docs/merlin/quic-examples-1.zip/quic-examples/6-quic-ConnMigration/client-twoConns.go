package main

import (
    "bufio"
    "context"
    "crypto/tls"
    "fmt"
    "io"
    "log"
    "os"
    "strings"
    "sync"
    "time"

    quic "github.com/quic-go/quic-go"
)

var (
    mu       sync.Mutex
    done     chan struct{}
)

func main() {
    tlsConfig := &tls.Config{
        InsecureSkipVerify: true,
        NextProtos:         []string{"quic-echo-example"},
    }

    // Connect to tr1 (localhost:4433)
    tr1, err := quic.DialAddr(context.Background(), "localhost:4433", tlsConfig, nil)
    if err != nil {
        log.Fatal(err)
    }
    stream1a, err := tr1.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }
    stream1b, err := tr1.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }

    // Connect to tr2 (127.0.0.1:4433)
    tr2, err := quic.DialAddr(context.Background(), "127.0.0.1:4433", tlsConfig, nil)
    if err != nil {
        log.Fatal(err)
    }
    stream2a, err := tr2.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }
    stream2b, err := tr2.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }

    // Start reading on all streams (they always print incoming data)
    go readFromServer(*stream1a, "tr1-stream-1")
    go readFromServer(*stream1b, "tr1-stream-2")
    go readFromServer(*stream2a, "tr2-stream-1")
    go readFromServer(*stream2b, "tr2-stream-2")

    // Start sending messages on tr1 streams initially
    done = make(chan struct{})
    go sendMessages(*stream1a, "client-tr1-stream-1", 1300*time.Millisecond, done)
    go sendMessages(*stream1b, "client-tr1-stream-2", 1800*time.Millisecond, done)

    // Keyboard to switch between tr1 and tr2 streams
    handleKeyboard(*tr1, *stream1a, *stream1b, *tr2, *stream2a, *stream2b)
}

func sendMessages(stream quic.Stream, streamName string, interval time.Duration, done <-chan struct{}) {
    counter := 1
    for {
        select {
        case <-done:
            fmt.Printf("[%s] Stopping sending messages\n", streamName)
            return
        default:
            msg := fmt.Sprintf("%s: msg-%d\n", streamName, counter)
            _, err := stream.Write([]byte(msg))
            if err != nil {
                log.Printf("Error writing to %s: %v\n", streamName, err)
                return
            }
            counter++
            time.Sleep(interval)
        }
    }
}

func readFromServer(stream quic.Stream, streamLabel string) {
    buf := make([]byte, 1024)
    for {
        n, err := stream.Read(buf)
        if err != nil {
            if err == io.EOF {
                log.Printf("Server closed %s.\n", streamLabel)
                return
            }
            log.Printf("Error reading from %s: %v\n", streamLabel, err)
            return
        }
        fmt.Printf("[%s] Received: %s", streamLabel, string(buf[:n]))
    }
}

func handleKeyboard(tr1 quic.Conn, s1a, s1b quic.Stream, tr2 quic.Conn, s2a, s2b quic.Stream) {
    reader := bufio.NewReader(os.Stdin)
    fmt.Println("Press '1' or 'a' for localhost, '2' or 'b' for 127.0.0.1, 'q' to quit")

    for {
        input, err := reader.ReadString('\n')
        if err != nil {
            log.Println("Error reading input:", err)
            continue
        }
        input = strings.TrimSpace(input)

        if input == "q" || input == "Q" {
            fmt.Println("Quitting client...")
            os.Exit(0)
        } else if input == "1" || input == "a" || input == "A" {
            fmt.Println("Switching to tr1 (localhost)")
            switchSending(tr1, s1a, s1b)
        } else if input == "2" || input == "b" || input == "B" {
            fmt.Println("Switching to tr2 (127.0.0.1)")
            switchSending(tr2, s2a, s2b)
        } else {
            fmt.Println("Keyboard input received:", input)
        }
    }
}

func switchSending(conn quic.Conn, streamA, streamB quic.Stream) {
    mu.Lock()
    defer mu.Unlock()
    // Stop current sending goroutines
    if done != nil {
        close(done)
    }
    done = make(chan struct{})

    // Start sending on new streams
    go sendMessages(streamA, fmt.Sprintf("client-%s-stream-1", conn.RemoteAddr()), 1300*time.Millisecond, done)
    go sendMessages(streamB, fmt.Sprintf("client-%s-stream-2", conn.RemoteAddr()), 1800*time.Millisecond, done)
}

