package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"os"
	"sync"
	"time"

	quic "github.com/quic-go/quic-go"
)

var (
	activeTr    *quic.Conn
	activeStr1  *quic.Stream
	activeStr2  *quic.Stream
	activeMutex sync.Mutex
	done        chan struct{}
)

func main() {
	tlsConfig := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"quic-echo-example"},
	}

	// Connect to two QUIC servers (here for example localhost:4433 and 127.0.0.1:4433)
	conn1, err := quic.DialAddr(context.Background(), "localhost:4433", tlsConfig, nil)
	if err != nil {
		log.Fatal(err)
	}

	conn2, err := quic.DialAddr(context.Background(), "127.0.0.1:4433", tlsConfig, nil)
	if err != nil {
		log.Fatal(err)
	}

	// Open streams on conn1
	s1, err := conn1.OpenStreamSync(context.Background())
	if err != nil {
		log.Fatal(err)
	}

	s2, err := conn1.OpenStreamSync(context.Background())
	if err != nil {
		log.Fatal(err)
	}

	activeMutex.Lock()
	activeTr = conn1
	activeStr1 = s1
	activeStr2 = s2
	activeMutex.Unlock()

	done = make(chan struct{})

	// Start goroutines for active streams and connection
	go readFromServer(activeStr1, "stream-1", done)
	go readFromServer(activeStr2, "stream-2", done)

	go sendMessages(activeStr1, "client-stream-1", 1300*time.Millisecond, done)
	go sendMessages(activeStr2, "client-stream-2", 1800*time.Millisecond, done)

	// Keyboard input handler with ability to switch active streams at runtime
	handleKeyboard(conn1, conn2)
}

// sendMessages continuously sends messages over the given stream until done is closed
func sendMessages(stream *quic.Stream, streamName string, interval time.Duration, done chan struct{}) {
	counter := 1
	for {
		select {
		case <-done:
			return
		default:
			msg := fmt.Sprintf("%s: msg-%d\n", streamName, counter)
			_, err := (*stream).Write([]byte(msg))
			if err != nil {
				log.Printf("Error writing to %s: %v\n", streamName, err)
				return
			}
			counter++
			time.Sleep(interval)
		}
	}
}

// readFromServer reads and prints server responses from the given stream until done is closed
func readFromServer(stream *quic.Stream, streamLabel string, done chan struct{}) {
	buf := make([]byte, 1024)
	for {
		select {
		case <-done:
			return
		default:
			n, err := (*stream).Read(buf)
			if err != nil {
				if err == io.EOF {
					log.Printf("Server closed %s.\n", streamLabel)
					return
				}
				log.Printf("Error reading from %s: %v\n", streamLabel, err)
				return
			}
			fmt.Printf("[%s] Received: %s", streamLabel, string(buf[:n]))
		}
	}
}

func handleKeyboard(conn1, conn2 *quic.Conn) {
	reader := bufio.NewReader(os.Stdin)
	fmt.Println("Press 'q' to quit, '1' to switch active connection to tr1 (localhost), '2' to switch to tr2 (127.0.0.1)")

	for {
		input, err := reader.ReadString('\n')
		if err != nil {
			log.Println("Error reading input:", err)
			continue
		}

		input = input[:len(input)-1] // strip newline

		switch input {
		case "q", "Q":
			fmt.Println("Quitting client...")
			close(done) // stop all goroutines
			os.Exit(0)
		case "1":
			fmt.Println("Switching active connection to tr1 (localhost)")
			switchActiveConnection(conn1)
		case "2":
			fmt.Println("Switching active connection to tr2 (127.0.0.1)")
			switchActiveConnection(conn2)
		default:
			fmt.Println("Keyboard input received:", input)
		}
	}
}

func switchActiveConnection(newConn *quic.Conn) {
	activeMutex.Lock()
	defer activeMutex.Unlock()

	// Close previous done to stop goroutines
	close(done)

	// Open new streams on newConn
	s1, err := newConn.OpenStreamSync(context.Background())
	if err != nil {
		log.Println("Failed to open stream-1 on new connection:", err)
		return
	}
	s2, err := newConn.OpenStreamSync(context.Background())
	if err != nil {
		log.Println("Failed to open stream-2 on new connection:", err)
		return
	}

	// Replace active connection and streams
	activeTr = newConn
	activeStr1 = s1
	activeStr2 = s2

	// Create new done channel for new goroutines
	done = make(chan struct{})

	// Start goroutines for new active streams
	go readFromServer(activeStr1, "stream-1", done)
	go readFromServer(activeStr2, "stream-2", done)

	go sendMessages(activeStr1, "client-stream-1", 1300*time.Millisecond, done)
	go sendMessages(activeStr2, "client-stream-2", 1800*time.Millisecond, done)
}

