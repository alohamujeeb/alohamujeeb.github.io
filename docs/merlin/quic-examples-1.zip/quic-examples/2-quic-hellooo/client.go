package main

import (
    "context"
    "crypto/tls"
    "fmt"
    "io"
    "log"

    quic "github.com/quic-go/quic-go"
)

func main() {
    tlsConfig := &tls.Config{
        InsecureSkipVerify: true, // for self-signed cert
    }

    session, err := quic.DialAddr(context.Background(), "localhost:4433", tlsConfig, nil)
    if err != nil {
        log.Fatal(err)
    }

    stream, err := session.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }

    // Send initial message to server
    _, err = stream.Write([]byte("Hello from client!"))
    if err != nil {
        log.Fatal(err)
    }

    // Keep reading messages from server
    buf := make([]byte, 1024)
    for {
        n, err := stream.Read(buf)
        if err != nil {
            if err == io.EOF {
                log.Println("Server closed the stream.")
                break
            }
            log.Fatal(err)
        }

        fmt.Print("Client received:", string(buf[:n]))
    }
}

