package main

import (
    "context"
    "crypto/tls"
    "fmt"
    "io"
    "log"
	"time"

    quic "github.com/quic-go/quic-go"
)

func main() {
    // TLS config
    tlsConfig := generateTLSConfig()

    // Start QUIC listener
    listener, err := quic.ListenAddr("localhost:4433", tlsConfig, nil)
    if err != nil {
        log.Fatal(err)
    }
    fmt.Println("QUIC server started on localhost:4433")

    for {
        // Accept a new connection
        conn, err := listener.Accept(context.Background())
        if err != nil {
            log.Fatal(err)
        }

        // Accept a stream
        stream, err := conn.AcceptStream(context.Background())
        if err != nil {
            log.Fatal(err)
        }

		go handleStream(*stream) // handle each stream in a separate goroutine
		 
    }
}


func handleStream(stream quic.Stream) {
    defer stream.Close()

    buf := make([]byte, 1024)
    n, err := stream.Read(buf)
    if err != nil && err != io.EOF {
        log.Println("Stream read error:", err)
        return
    }

    fmt.Println("Server received:", string(buf[:n]))

    counter := 1
    for {
        msg := fmt.Sprintf("Hello from server-%d", counter)
        _, err := stream.Write([]byte(msg + "\n"))
        if err != nil {
            log.Println("Stream write error:", err)
            return
        }
        counter++
        time.Sleep(1 * time.Second)
    }
}



// Load TLS cert + key
func generateTLSConfig() *tls.Config {
    cert, err := tls.LoadX509KeyPair("cert.pem", "key.pem")
    if err != nil {
        log.Fatal(err)
    }
    return &tls.Config{Certificates: []tls.Certificate{cert}}
}
