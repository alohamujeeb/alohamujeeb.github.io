package main

import (
	"fmt"
	"crypto/tls"
	"log"
	"net"

)



func main() {
	
	ethStr := "eth0"
	wifiStr := "lo"
	//loopbackStr := "lo"
	

	tlsConf := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"quic-echo-example"},
	}

	fmt.Println("tlsConf=",tlsConf,"\n")
	

	serverAddrStr := "localhost:4433" // <-- replace this with actual server IP
	serverAddr, err := net.ResolveUDPAddr("udp", serverAddrStr)
	if err != nil {
		log.Fatalf("Failed to resolve server address: %v", err)
	}
	fmt.Println("serverAddr:", serverAddr)
	

	// ---- Ethernet  ----
	ethIP, err := getInterfaceIPv4(ethStr)
	if err != nil {
		log.Fatalf("Failed to get eth0 IP: %v", err)
	}
	fmt.Println("ethIP:", ethIP)
	
	// ---- Wait, then AddPath for Wi-Fi (wls0) ----
	//time.Sleep(5 * time.Second) //why?
	
	wifiIP, err := getInterfaceIPv4(wifiStr)
	if err != nil {
		log.Fatalf("Failed to get Wi-Fi IP: %v", err)
	}
	fmt.Printf("Wi-Fi IP: %s\n", wifiIP.String())


	//==================================
	ethUDPConn, err := net.ListenUDP("udp", &net.UDPAddr{IP: ethIP, Port: 0})
	if err != nil {
		log.Fatalf("Failed to bind UDP socket to eth: %v", err)
	}
	defer ethUDPConn.Close()
	ethAddr := ethUDPConn.LocalAddr().(*net.UDPAddr)
	fmt.Println("Ethernet IP and port:", ethAddr.IP, ethAddr.Port)


	wifiUDPConn, err := net.ListenUDP("udp", &net.UDPAddr{IP: wifiIP, Port: 0})
	if err != nil {
		log.Fatalf("Failed to bind UDP socket to wifi: %v", err)
	}
	defer wifiUDPConn.Close()
	wifiAddr := wifiUDPConn.LocalAddr().(*net.UDPAddr)
	fmt.Println("Wifi IP and port:", wifiAddr.IP, wifiAddr.Port)
	
	
	
	//go handleKeyboard(*ethConn, *wifiConn)
	
} //main() ends




func getInterfaceIPv4(ifaceName string) (net.IP, error) {
	iface, err := net.InterfaceByName(ifaceName)
	if err != nil {
		return nil, fmt.Errorf("interface %s not found: %w", ifaceName, err)
	}
	addrs, err := iface.Addrs()
	if err != nil {
		return nil, fmt.Errorf("failed to get addresses for %s: %w", ifaceName, err)
	}
	for _, addr := range addrs {
		switch v := addr.(type) {
		case *net.IPNet:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		case *net.IPAddr:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		}
	}
	return nil, fmt.Errorf("no IPv4 address found on interface %s", ifaceName)
}

func generateTLSConfig() *tls.Config {
	return &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"quic-echo-example"},
	}
}


