package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"net"
	"os"
	"strings"
	"sync/atomic"
	"time"

	quic "github.com/quic-go/quic-go"
)

// SwappablePacketConn wraps a net.PacketConn and allows swapping underlying UDPConn safely.
type SwappablePacketConn struct {
	conn atomic.Value // holds net.PacketConn (actually *net.UDPConn)
}

func NewSwappablePacketConn(initial net.PacketConn) *SwappablePacketConn {
	spc := &SwappablePacketConn{}
	spc.conn.Store(initial)
	return spc
}

func (spc *SwappablePacketConn) ReadFrom(p []byte) (int, net.Addr, error) {
	conn := spc.conn.Load().(net.PacketConn)
	return conn.ReadFrom(p)
}

func (spc *SwappablePacketConn) WriteTo(p []byte, addr net.Addr) (int, error) {
	conn := spc.conn.Load().(net.PacketConn)
	return conn.WriteTo(p, addr)
}

func (spc *SwappablePacketConn) Close() error {
	conn := spc.conn.Load().(net.PacketConn)
	return conn.Close()
}

func (spc *SwappablePacketConn) LocalAddr() net.Addr {
	conn := spc.conn.Load().(net.PacketConn)
	return conn.LocalAddr()
}

func (spc *SwappablePacketConn) SetDeadline(t time.Time) error {
	conn := spc.conn.Load().(net.PacketConn)
	return conn.SetDeadline(t)
}

func (spc *SwappablePacketConn) SetReadDeadline(t time.Time) error {
	conn := spc.conn.Load().(net.PacketConn)
	return conn.SetReadDeadline(t)
}

func (spc *SwappablePacketConn) SetWriteDeadline(t time.Time) error {
	conn := spc.conn.Load().(net.PacketConn)
	return conn.SetWriteDeadline(t)
}

// Swap underlying UDPConn (must NOT close old one here, just swap reference)
func (spc *SwappablePacketConn) Swap(newConn net.PacketConn) {
	oldConn := spc.conn.Swap(newConn).(net.PacketConn)
	fmt.Printf("Switched active UDP connection from %s to %s\n", oldConn.LocalAddr(), newConn.LocalAddr())
}

func main() {

	ethStr := "eth0"
	wifiStr := "wifi0" //put lo for testing if wifi not available

    if err := listInterfaces(); err != nil {
        log.Fatalf("Error listing interfaces: %v", err)
    }
	


	tlsConf := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"quic-echo-example"},
	}

	//serverAddrStr := "localhost:4433" // Replace if needed
	serverAddrStr := "157.230.33.15:4433" // Replace if needed

	serverAddr, err := net.ResolveUDPAddr("udp", serverAddrStr)
	if err != nil {
		log.Fatalf("Failed to resolve server address: %v", err)
	}
	fmt.Println("serverAddr:", serverAddr)

	// ---- Ethernet  ----
	ethIP, err := getInterfaceIPv4(ethStr)
	if err != nil {
		log.Fatalf("Failed to get eth0 IP: %v", err)
	}
	fmt.Println("ethIP:", ethIP)

	// ---- Wi-Fi  ----
	wifiIP, err := getInterfaceIPv4(wifiStr)
	if err != nil {
		log.Fatalf("Failed to get Wi-Fi IP: %v", err)
	}
	fmt.Printf("Wi-Fi IP: %s\n", wifiIP.String())

	//==================================
	ethUDPConn, err := net.ListenUDP("udp", &net.UDPAddr{IP: ethIP, Port: 0})
	if err != nil {
		log.Fatalf("Failed to bind UDP socket to eth: %v", err)
	}
	defer ethUDPConn.Close()
	ethAddr := ethUDPConn.LocalAddr().(*net.UDPAddr)
	fmt.Println("Ethernet IP and port:", ethAddr.IP, ethAddr.Port)

	wifiUDPConn, err := net.ListenUDP("udp", &net.UDPAddr{IP: wifiIP, Port: 0})
	if err != nil {
		log.Fatalf("Failed to bind UDP socket to wifi: %v", err)
	}
	defer wifiUDPConn.Close()
	wifiAddr := wifiUDPConn.LocalAddr().(*net.UDPAddr)
	fmt.Println("Wi-Fi IP and port:", wifiAddr.IP, wifiAddr.Port)

	// ------------------
	// Start with Wi-Fi UDPConn wrapped inside SwappablePacketConn
	swappableConn := NewSwappablePacketConn(wifiUDPConn)

	session, err := quic.Dial(
		context.Background(),
		swappableConn,
		serverAddr,
		tlsConf,
		nil,
	)
	if err != nil {
		log.Fatalf("Failed to dial QUIC server: %v", err)
	}
	defer session.CloseWithError(0, "client done")

	fmt.Println("Connected to server:", session.RemoteAddr())

	stream, err := session.OpenStreamSync(context.Background())
	if err != nil {
		log.Fatalf("Failed to open stream: %v", err)
	}
	defer stream.Close()

	quitCh := make(chan struct{})

	// Start keyboard input goroutine - pass swappableConn and UDPConns
	go handleKeyboardInput(quitCh, swappableConn, ethUDPConn, wifiUDPConn)

	// Read from stream goroutine
	go func() {
		buf := make([]byte, 1024)
		for {
			n, err := stream.Read(buf)
			if err != nil {
				log.Println("Stream read error:", err)
				return
			}
			fmt.Printf("Received from server: %s", string(buf[:n]))
		}
	}()

	// Write to stream every 1 second until quit
	counter := 1
loop:
	for {
		select {
		case <-quitCh:
			fmt.Println("Quitting client...")
			break loop
		default:
			msg := fmt.Sprintf("Hello from client-%d\n", counter)
			_, err := stream.Write([]byte(msg))
			if err != nil {
				log.Println("Stream write error:", err)
				break loop
			}
			counter++
			time.Sleep(1 * time.Second)
		}
	}
}

func handleKeyboardInput(quitCh chan<- struct{}, spc *SwappablePacketConn, ethConn, wifiConn *net.UDPConn) {
	reader := bufio.NewReader(os.Stdin)
	for {
		fmt.Print("Enter 'q' to quit, 'i' to show IP/port, 'w' for Wi-Fi, 'e' for Ethernet: ")
		input, err := reader.ReadString('\n')
		if err != nil {
			log.Println("Error reading keyboard input:", err)
			continue
		}
		input = strings.TrimSpace(input)
		if len(input) == 0 {
			continue
		}
		switch strings.ToLower(input) {
		case "q":
			quitCh <- struct{}{}
			return
		case "i":
			printConnectionInfo(spc)
		case "w":
			spc.Swap(wifiConn)
		case "e":
			spc.Swap(ethConn)
		default:
			fmt.Println("Unknown command")
		}
	}
}

func printConnectionInfo(spc *SwappablePacketConn) {
	conn := spc.conn.Load().(net.PacketConn)
	addr := conn.LocalAddr().(*net.UDPAddr)
	fmt.Printf("Active connection - IP: %s, Port: %d\n", addr.IP, addr.Port)
}

func getInterfaceIPv4(ifaceName string) (net.IP, error) {
	iface, err := net.InterfaceByName(ifaceName)
	if err != nil {
		return nil, fmt.Errorf("interface %s not found: %w", ifaceName, err)
	}
	addrs, err := iface.Addrs()
	if err != nil {
		return nil, fmt.Errorf("failed to get addresses for %s: %w", ifaceName, err)
	}
	for _, addr := range addrs {
		switch v := addr.(type) {
		case *net.IPNet:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		case *net.IPAddr:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		}
	}
	return nil, fmt.Errorf("no IPv4 address found on interface %s", ifaceName)
}



func listInterfaces() error {
    ifaces, err := net.Interfaces()
    if err != nil {
        return fmt.Errorf("failed to get interfaces: %w", err)
    }

	fmt.Println("==============================================")
    fmt.Println("Available network interfaces and their IPv4 addresses:")
    for _, iface := range ifaces {
        addrs, err := iface.Addrs()
        if err != nil {
            fmt.Printf("Failed to get addresses for interface %s: %v\n", iface.Name, err)
            continue
        }

        var ipv4Addrs []string
        for _, addr := range addrs {
            switch v := addr.(type) {
            case *net.IPNet:
                ip := v.IP.To4()
                if ip != nil {
                    ipv4Addrs = append(ipv4Addrs, ip.String())
                }
            case *net.IPAddr:
                ip := v.IP.To4()
                if ip != nil {
                    ipv4Addrs = append(ipv4Addrs, ip.String())
                }
            }
        }

        fmt.Printf(" - %s: %v\n", iface.Name, ipv4Addrs)
    }
	fmt.Println("==============================================")
    return nil
}
