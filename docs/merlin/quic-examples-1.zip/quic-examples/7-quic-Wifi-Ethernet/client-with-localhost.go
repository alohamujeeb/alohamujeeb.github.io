package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"net"
	"time"

	quic "github.com/quic-go/quic-go"
)

func main() {
	tlsConf := generateTLSConfig()

	// Replace with your server's IP and port
	serverAddr := "localhost:4433"

	// Get Ethernet interface IP - replace "eth0" with your interface name
	//ethIP, err := getInterfaceIPv4("eth0")
	ethIP, err := getInterfaceIPv4("lo")
	if err != nil {
		log.Fatalf("Failed to get Ethernet IP: %v", err)
	}
	fmt.Printf("Using Ethernet IP: %s\n", ethIP.String())

	// Bind UDP socket to Ethernet IP
	laddr := &net.UDPAddr{IP: ethIP, Port: 0}
	udpConn, err := net.ListenUDP("udp", laddr)
	if err != nil {
		log.Fatalf("Failed to bind UDP socket: %v", err)
	}
	defer udpConn.Close()

	// Resolve server UDP address
	raddr, err := net.ResolveUDPAddr("udp", serverAddr)
	if err != nil {
		log.Fatalf("Failed to resolve server address: %v", err)
	}

	// Dial QUIC session over the bound UDP socket
	session, err := quic.Dial(context.Background(), udpConn, raddr, tlsConf, nil)
	if err != nil {
		log.Fatalf("Failed to dial QUIC session: %v", err)
	}
	defer session.CloseWithError(0, "bye")

	fmt.Printf("Connected to %s over Ethernet interface\n", serverAddr)

	// Open a stream
	stream, err := session.OpenStreamSync(context.Background())
	if err != nil {
		log.Fatalf("Failed to open stream: %v", err)
	}
	defer stream.Close()

	// Read responses in background
	go func() {
		buf := make([]byte, 1024)
		for {
			n, err := stream.Read(buf)
			if err != nil {
				log.Printf("Stream read error or closed: %v", err)
				return
			}
			fmt.Printf("Server says: %s", string(buf[:n]))
		}
	}()

	// Send messages every 2 seconds
	counter := 1
	for {
		msg := fmt.Sprintf("Hello from client over Ethernet #%d\n", counter)
		_, err := stream.Write([]byte(msg))
		if err != nil {
			log.Printf("Write error: %v", err)
			return
		}
		counter++
		time.Sleep(2 * time.Second)
	}
}

// getInterfaceIPv4 fetches the first IPv4 address of the given network interface
func getInterfaceIPv4(ifaceName string) (net.IP, error) {
	iface, err := net.InterfaceByName(ifaceName)
	if err != nil {
		return nil, fmt.Errorf("interface %s not found: %w", ifaceName, err)
	}
	addrs, err := iface.Addrs()
	if err != nil {
		return nil, fmt.Errorf("failed to get addresses for %s: %w", ifaceName, err)
	}
	for _, addr := range addrs {
		switch v := addr.(type) {
		case *net.IPNet:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		case *net.IPAddr:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		}
	}
	return nil, fmt.Errorf("no IPv4 address found on interface %s", ifaceName)
}

func generateTLSConfig() *tls.Config {
	return &tls.Config{
		InsecureSkipVerify: true, // For testing only! Remove in production!
		NextProtos:         []string{"quic-echo-example"},
	}
}

