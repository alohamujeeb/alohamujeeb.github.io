package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"net"
	"os"
	"time"

	quic "github.com/quic-go/quic-go"
)

func main() {

	ethStr := "eth0"
	wifiStr := "lo"

	tlsConf := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"quic-echo-example"},
	}

	serverAddrStr := "localhost:4433" // Replace with actual server IP if needed

	serverAddr, err := net.ResolveUDPAddr("udp", serverAddrStr)
	if err != nil {
		log.Fatalf("Failed to resolve server address: %v", err)
	}
	fmt.Println("serverAddr:", serverAddr)

	// ---- Ethernet  ----
	ethIP, err := getInterfaceIPv4(ethStr)
	if err != nil {
		log.Fatalf("Failed to get eth0 IP: %v", err)
	}
	fmt.Println("ethIP:", ethIP)

	// ---- Wi-Fi  ----
	wifiIP, err := getInterfaceIPv4(wifiStr)
	if err != nil {
		log.Fatalf("Failed to get Wi-Fi IP: %v", err)
	}
	fmt.Printf("Wi-Fi IP: %s\n", wifiIP.String())

	//==================================
	ethUDPConn, err := net.ListenUDP("udp", &net.UDPAddr{IP: ethIP, Port: 0})
	if err != nil {
		log.Fatalf("Failed to bind UDP socket to eth: %v", err)
	}
	defer ethUDPConn.Close()
	ethAddr := ethUDPConn.LocalAddr().(*net.UDPAddr)
	fmt.Println("Ethernet IP and port:", ethAddr.IP, ethAddr.Port)

	wifiUDPConn, err := net.ListenUDP("udp", &net.UDPAddr{IP: wifiIP, Port: 0})
	if err != nil {
		log.Fatalf("Failed to bind UDP socket to wifi: %v", err)
	}
	defer wifiUDPConn.Close()
	wifiAddr := wifiUDPConn.LocalAddr().(*net.UDPAddr)
	fmt.Println("Wi-Fi IP and port:", wifiAddr.IP, wifiAddr.Port)

	// ------------------
	// Dial QUIC server using Wi-Fi UDP socket only
	session, err := quic.Dial(
		context.Background(),
		wifiUDPConn, // Use Wi-Fi UDP socket explicitly
		serverAddr,
		tlsConf,
		nil,
	)
	if err != nil {
		log.Fatalf("Failed to dial QUIC server: %v", err)
	}
	defer session.CloseWithError(0, "client done")

	fmt.Println("Connected to server:", session.RemoteAddr())

	stream, err := session.OpenStreamSync(context.Background())
	if err != nil {
		log.Fatalf("Failed to open stream: %v", err)
	}
	defer stream.Close()

	quitCh := make(chan struct{})

	// Start keyboard input goroutine - pass the active UDP connection (Wi-Fi)
	go handleKeyboardInput(quitCh, wifiUDPConn)

	// Read from stream goroutine
	go func() {
		buf := make([]byte, 1024)
		for {
			n, err := stream.Read(buf)
			if err != nil {
				log.Println("Stream read error:", err)
				return
			}
			fmt.Printf("Received from server: %s", string(buf[:n]))
		}
	}()

	// Write to stream every 1 second until quit
	counter := 1
loop:
	for {
		select {
		case <-quitCh:
			fmt.Println("Quitting client...")
			break loop
		default:
			msg := fmt.Sprintf("Hello from client-%d\n", counter)
			_, err := stream.Write([]byte(msg))
			if err != nil {
				log.Println("Stream write error:", err)
				break loop
			}
			counter++
			time.Sleep(1 * time.Second)
		}
	}
}

func handleKeyboardInput(quitCh chan<- struct{}, activeUDPConn *net.UDPConn) {
	reader := bufio.NewReader(os.Stdin)
	for {
		fmt.Print("Enter 'q' to quit, 'i' to show IP/port: ")
		input, err := reader.ReadString('\n')
		if err != nil {
			log.Println("Error reading keyboard input:", err)
			continue
		}
		if len(input) > 0 {
			switch input[0] {
			case 'q', 'Q':
				quitCh <- struct{}{}
				return
			case 'i', 'I':
				printConnectionInfo(activeUDPConn)
			default:
				fmt.Println("Unknown command")
			}
		}
	}
}

func printConnectionInfo(activeUDPConn *net.UDPConn) {
	addr := activeUDPConn.LocalAddr().(*net.UDPAddr)
	fmt.Printf("Active connection - IP: %s, Port: %d\n", addr.IP, addr.Port)
}

func getInterfaceIPv4(ifaceName string) (net.IP, error) {
	iface, err := net.InterfaceByName(ifaceName)
	if err != nil {
		return nil, fmt.Errorf("interface %s not found: %w", ifaceName, err)
	}
	addrs, err := iface.Addrs()
	if err != nil {
		return nil, fmt.Errorf("failed to get addresses for %s: %w", ifaceName, err)
	}
	for _, addr := range addrs {
		switch v := addr.(type) {
		case *net.IPNet:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		case *net.IPAddr:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		}
	}
	return nil, fmt.Errorf("no IPv4 address found on interface %s", ifaceName)
}

