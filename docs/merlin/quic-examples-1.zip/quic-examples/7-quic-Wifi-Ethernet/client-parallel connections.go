package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"log"
	"net"
	"os"
	"sync"
	"time"

	quic "github.com/quic-go/quic-go"
)

var (
	activeConn  quic.Conn
	activeStream quic.Stream
	activeMutex sync.Mutex
	done        chan struct{}
)

func main() {
	tlsConf := generateTLSConfig()

	serverAddr := "localhost:4433"

	//ethIP, err := getInterfaceIPv4("eth0")
	ethIP, err := getInterfaceIPv4("lo")
	if err != nil {
		log.Fatalf("Failed to get Ethernet IP: %v", err)
	}
	fmt.Printf("Using Ethernet IP: %s\n", ethIP.String())

	//wifiIP, err := getInterfaceIPv4("wls0")
	wifiIP, err := getInterfaceIPv4("lo")
	if err != nil {
		log.Fatalf("Failed to get Wi-Fi IP: %v", err)
	}
	fmt.Printf("Using Wi-Fi IP: %s\n", wifiIP.String())

	ethUDPConn, err := net.ListenUDP("udp", &net.UDPAddr{IP: ethIP, Port: 0})
	if err != nil {
		log.Fatalf("Failed to bind UDP socket to eth0: %v", err)
	}
	defer ethUDPConn.Close()

	wifiUDPConn, err := net.ListenUDP("udp", &net.UDPAddr{IP: wifiIP, Port: 0})
	if err != nil {
		log.Fatalf("Failed to bind UDP socket to wls0: %v", err)
	}
	defer wifiUDPConn.Close()

	raddr, err := net.ResolveUDPAddr("udp", serverAddr)
	if err != nil {
		log.Fatalf("Failed to resolve server address: %v", err)
	}

	ethConn, err := quic.Dial(context.Background(), ethUDPConn, raddr, tlsConf, nil)
	if err != nil {
		log.Fatalf("Failed to dial QUIC on eth0: %v", err)
	}
	defer ethConn.CloseWithError(0, "bye")

	wifiConn, err := quic.Dial(context.Background(), wifiUDPConn, raddr, tlsConf, nil)
	if err != nil {
		log.Fatalf("Failed to dial QUIC on wls0: %v", err)
	}
	defer wifiConn.CloseWithError(0, "bye")

	switchActiveConnection(*ethConn)

	done = make(chan struct{})

	go handleKeyboard(*ethConn, *wifiConn)

	select {}
}

func switchActiveConnection(newConn quic.Conn) {
	activeMutex.Lock()
	defer activeMutex.Unlock()

	if done != nil {
		close(done)
	}

	done = make(chan struct{})

	activeConn = newConn

	stream, err := newConn.OpenStreamSync(context.Background())
	if err != nil {
		log.Fatalf("Failed to open stream on new connection: %v", err)
	}
	activeStream = *stream

	go readFromServer(activeStream, done)
	go sendMessages(activeStream, done)
}

func sendMessages(stream quic.Stream, done chan struct{}) {
	counter := 1
	for {
		select {
		case <-done:
			return
		default:
			msg := fmt.Sprintf("Hello from client #%d\n", counter)
			_, err := stream.Write([]byte(msg))
			if err != nil {
				log.Printf("Write error: %v", err)
				return
			}
			counter++
			time.Sleep(2 * time.Second)
		}
	}
}

func readFromServer(stream quic.Stream, done chan struct{}) {
	buf := make([]byte, 1024)
	for {
		select {
		case <-done:
			return
		default:
			n, err := stream.Read(buf)
			if err != nil {
				log.Printf("Stream read error or closed: %v", err)
				return
			}
			fmt.Printf("Server says: %s", string(buf[:n]))
		}
	}
}

func handleKeyboard(ethConn, wifiConn quic.Conn) {
	reader := bufio.NewReader(os.Stdin)
	fmt.Println("Press '1' to switch to Ethernet connection, '2' for Wi-Fi, 'q' to quit.")

	for {
		input, err := reader.ReadString('\n')
		if err != nil {
			log.Println("Error reading input:", err)
			continue
		}
		input = input[:len(input)-1]

		switch input {
		case "1":
			fmt.Println("Switching to Ethernet connection...")
			switchActiveConnection(ethConn)
		case "2":
			fmt.Println("Switching to Wi-Fi connection...")
			switchActiveConnection(wifiConn)
		case "q", "Q":
			fmt.Println("Quitting client...")
			activeMutex.Lock()
			if done != nil {
				close(done)
			}
			activeMutex.Unlock()
			os.Exit(0)
		default:
			fmt.Println("Unknown input:", input)
		}
	}
}

func getInterfaceIPv4(ifaceName string) (net.IP, error) {
	iface, err := net.InterfaceByName(ifaceName)
	if err != nil {
		return nil, fmt.Errorf("interface %s not found: %w", ifaceName, err)
	}
	addrs, err := iface.Addrs()
	if err != nil {
		return nil, fmt.Errorf("failed to get addresses for %s: %w", ifaceName, err)
	}
	for _, addr := range addrs {
		switch v := addr.(type) {
		case *net.IPNet:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		case *net.IPAddr:
			if ip := v.IP.To4(); ip != nil {
				return ip, nil
			}
		}
	}
	return nil, fmt.Errorf("no IPv4 address found on interface %s", ifaceName)
}

func generateTLSConfig() *tls.Config {
	return &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"quic-echo-example"},
	}
}
