package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"net"
	"time"

	quic "github.com/quic-go/quic-go"
)

func main() {
	tlsConf := generateTLSConfig()
	listenAddress := "0.0.0.0:4433"

	// 🔧 Explicitly resolve and bind UDP to get *net.UDPConn
	udpAddr, err := net.ResolveUDPAddr("udp", listenAddress)
	if err != nil {
		log.Fatalf("Failed to resolve UDP address: %v", err)
	}

	udpConn, err := net.ListenUDP("udp", udpAddr)
	if err != nil {
		log.Fatalf("Failed to create UDP listener: %v", err)
	}

	// ✅ Pass *net.UDPConn to quic.Listen to avoid buffer warning
	listener, err := quic.Listen(udpConn, tlsConf, nil)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("Listening on %s\n", listenAddress)

	for {
		conn, err := listener.Accept(context.Background())
		if err != nil {
			log.Println("Failed to accept connection:", err)
			continue
		}

		go handleConnection(*conn)
	}
}

func handleConnection(conn quic.Conn) {
	fmt.Println("Accepted new connection from", conn.RemoteAddr())

	for {
		stream, err := conn.AcceptStream(context.Background())
		if err != nil {
			log.Println("Error accepting stream:", err)
			return
		}
		go handleStream(*stream)
	}
}

func handleStream(stream quic.Stream) {
	defer stream.Close()

	// Read incoming data
	go func() {
		buf := make([]byte, 1024)
		for {
			n, err := stream.Read(buf)
			if err != nil {
				if err == io.EOF {
					log.Println("Client closed stream")
				} else {
					log.Println("Stream read error:", err)
				}
				return
			}
			fmt.Printf("Received: %s", string(buf[:n]))
		}
	}()

	// Write periodic messages to client
	counter := 1
	for {
		msg := fmt.Sprintf("Hello from server-%d\n", counter)
		_, err := stream.Write([]byte(msg))
		if err != nil {
			log.Println("Stream write error:", err)
			return
		}
		counter++
		time.Sleep(1 * time.Second)
	}
}

func generateTLSConfig() *tls.Config {
	cert, err := tls.LoadX509KeyPair("cert.pem", "key.pem")
	if err != nil {
		log.Fatal("Failed to load TLS certificates:", err)
	}
	return &tls.Config{
		Certificates: []tls.Certificate{cert},
		NextProtos:   []string{"quic-echo-example"},
	}
}

