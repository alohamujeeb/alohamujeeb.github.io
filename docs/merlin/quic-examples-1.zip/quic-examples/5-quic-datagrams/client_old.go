package main

import (
    "bufio"
    "context"
    "crypto/tls"
    "fmt"
    "io"
    "log"
    "os"
    "time"

    quic "github.com/quic-go/quic-go"
)

func main() {
    tlsConfig := &tls.Config{
        InsecureSkipVerify: true, // for self-signed cert
        NextProtos:         []string{"quic-echo-example"},
    }

    // Connect to the QUIC server
    conn, err := quic.DialAddr(context.Background(), "localhost:4433", tlsConfig, &quic.Config{
        EnableDatagrams: true,
    })
    if err != nil {
        log.Fatal(err)
    }

    // Open a single stream
    stream, err := conn.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }

    // Start stream reader
    go readFromServer(*stream, "stream")

    // Start sending stream messages every 1s
    go sendStreamMessages(*stream, "client-stream", 3*time.Second)

    // Start sending datagrams every 1s
    go sendDatagramMessages(*conn, "client-datagram", 40*time.Millisecond)

    // Start keyboard listener
    handleKeyboard()
}

// Send messages over a stream at given interval
func sendStreamMessages(stream quic.Stream, streamName string, interval time.Duration) {
    counter := 1
    for {
        msg := fmt.Sprintf("%s: msg-%d\n", streamName, counter)
        _, err := stream.Write([]byte(msg))
        if err != nil {
            log.Printf("Error writing to stream: %v\n", err)
            return
        }
        counter++
        time.Sleep(interval)
    }
}

// Send messages as datagrams at given interval
func sendDatagramMessages(session quic.Conn, label string, interval time.Duration) {
    counter := 1
    for {
        msg := fmt.Sprintf("%s: msg-%d", label, counter)
        err := session.SendDatagram([]byte(msg))
        if err != nil {
            log.Printf("Error sending datagram: %v\n", err)
            return
        }
        counter++
        time.Sleep(interval)
    }
}

// Read from stream
func readFromServer(stream quic.Stream, streamLabel string) {
    buf := make([]byte, 1024)
    for {
        n, err := stream.Read(buf)
        if err != nil {
            if err == io.EOF {
                log.Printf("Server closed %s.\n", streamLabel)
                return
            }
            log.Printf("Error reading from %s: %v\n", streamLabel, err)
            return
        }
        fmt.Printf("[%s] Received: %s", streamLabel, string(buf[:n]))
    }
}

// Keyboard input handler
func handleKeyboard() {
    reader := bufio.NewReader(os.Stdin)
    for {
        input, err := reader.ReadString('\n')
        if err != nil {
            log.Println("Error reading input:", err)
            continue
        }

        input = input[:len(input)-1] // strip newline

        if input == "q" || input == "Q" {
            fmt.Println("Quitting client...")
            os.Exit(0)
        } else {
            fmt.Println("Keyboard input received:", input)
        }
    }
}

