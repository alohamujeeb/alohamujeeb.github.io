package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"time"

	quic "github.com/quic-go/quic-go"
)

func main() {
	tlsConf := generateTLSConfig()

	listener, err := quic.ListenAddr("localhost:4433", tlsConf, &quic.Config{
		EnableDatagrams: true, // Enable datagrams support
	})
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Listening on localhost:4433")

	for {
		conn, err := listener.Accept(context.Background())
		if err != nil {
			log.Println("Failed to accept connection:", err)
			continue
		}

		go handleConnection(*conn)
	}
}

func handleConnection(conn quic.Conn) {
	fmt.Println("Accepted new connection")

	// Handle streams concurrently
	go func() {
		for {
			stream, err := conn.AcceptStream(context.Background())
			if err != nil {
				log.Println("Error accepting stream:", err)
				return
			}
			go streamHandle(*stream)
		}
	}()

	// Handle datagrams concurrently in main goroutine
	go datagramHandle(conn)
}

func streamHandle(stream quic.Stream) {
	defer stream.Close()

	// Reading incoming stream data
	go func() {
		buf := make([]byte, 1024)
		for {
			n, err := stream.Read(buf)
			if err != nil {
				if err == io.EOF {
					log.Println("Client closed stream")
				} else {
					log.Println("Stream read error:", err)
				}
				return
			}
			fmt.Printf("Received stream data: %s", string(buf[:n]))
		}
	}()

	// Sending periodic messages on stream
	counter := 1
	for {
		msg := fmt.Sprintf("Hello from server-%d\n", counter)
		_, err := stream.Write([]byte(msg))
		if err != nil {
			log.Println("Stream write error:", err)
			return
		}
		counter++
		time.Sleep(1 * time.Second)
	}
}

func datagramHandle(conn quic.Conn) {
	for {
		msg, err := conn.ReceiveDatagram(context.Background())
		if err != nil {
			log.Println("Datagram receive error:", err)
			return
		}
		fmt.Printf("Received datagram: %s\n", string(msg))
	}
}

func generateTLSConfig() *tls.Config {
	cert, err := tls.LoadX509KeyPair("cert.pem", "key.pem")
	if err != nil {
		log.Fatal(err)
	}
	return &tls.Config{
		Certificates: []tls.Certificate{cert},
		NextProtos:   []string{"quic-echo-example"},
	}
}
