package main

import (
    "context"
    "crypto/tls"
    "fmt"
    "io"
    "log"
    "time"

    quic "github.com/quic-go/quic-go"
)

func main() {
    tlsConfig := &tls.Config{
        InsecureSkipVerify: true, // for self-signed cert
        NextProtos:         []string{"quic-echo-example"},
    }

    session, err := quic.DialAddr(context.Background(), "localhost:4433", tlsConfig, nil)
    if err != nil {
        log.Fatal(err)
    }

    stream, err := session.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }

    go readFromServer(*stream)

    counter := 1
    for {
        msg := fmt.Sprintf("Hello from client-%d\n", counter)
        _, err := stream.Write([]byte(msg))
        if err != nil {
            log.Fatal(err)
        }
        counter++
        time.Sleep(2 * time.Second)
    }
}

func readFromServer(stream quic.Stream) {
    buf := make([]byte, 1024)
    for {
        n, err := stream.Read(buf)
        if err != nil {
            if err == io.EOF {
                log.Println("Server closed the stream.")
                return
            }
            log.Fatal(err)
        }
        fmt.Print("Client received: ", string(buf[:n]))
    }
}

