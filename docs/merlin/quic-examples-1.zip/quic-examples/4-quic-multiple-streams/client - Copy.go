package main

import (
    "bufio"
    "context"
    "crypto/tls"
    "fmt"
    "io"
    "log"
    "os"
    "time"

    quic "github.com/quic-go/quic-go"
)

func main() {
    tlsConfig := &tls.Config{
        InsecureSkipVerify: true, // for self-signed cert
        NextProtos:         []string{"quic-echo-example"},
    }

    // Connect to the QUIC server
    session, err := quic.DialAddr(context.Background(), "localhost:4433", tlsConfig, nil)
    if err != nil {
        log.Fatal(err)
    }

    // Open stream-1
    stream1, err := session.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }

    // Open stream-2
    stream2, err := session.OpenStreamSync(context.Background())
    if err != nil {
        log.Fatal(err)
    }

    // Start readers for each stream
    go readFromServer(*stream1, "stream-1")
    go readFromServer(*stream2, "stream-2")

    // Start sending messages on stream-1 every 1.3s
    go sendMessages(*stream1, "client-stream-1", 1300*time.Millisecond)

    // Start sending messages on stream-2 every 1.8s
    go sendMessages(*stream2, "client-stream-2", 1800*time.Millisecond)

    // Start keyboard listener
    handleKeyboard()
}

// Continuously send messages over the given stream
func sendMessages(stream quic.Stream, streamName string, interval time.Duration) {
    counter := 1
    for {
        msg := fmt.Sprintf("%s: msg-%d\n", streamName, counter)
        _, err := stream.Write([]byte(msg))
        if err != nil {
            log.Printf("Error writing to %s: %v\n", streamName, err)
            return
        }
        counter++
        time.Sleep(interval)
    }
}

// Reads and prints server responses from a given stream
func readFromServer(stream quic.Stream, streamLabel string) {
    buf := make([]byte, 1024)
    for {
        n, err := stream.Read(buf)
        if err != nil {
            if err == io.EOF {
                log.Printf("Server closed %s.\n", streamLabel)
                return
            }
            log.Printf("Error reading from %s: %v\n", streamLabel, err)
            return
        }
        fmt.Printf("[%s] Received: %s", streamLabel, string(buf[:n]))
    }
}

// Listens to keyboard input: 'q' quits, other input is printed
func handleKeyboard() {
    reader := bufio.NewReader(os.Stdin)
    for {
        input, err := reader.ReadString('\n')
        if err != nil {
            log.Println("Error reading input:", err)
            continue
        }

        input = input[:len(input)-1] // strip newline

        if input == "q" || input == "Q" {
            fmt.Println("Quitting client...")
            os.Exit(0)
        } else {
            fmt.Println("Keyboard input received:", input)
        }
    }
}

